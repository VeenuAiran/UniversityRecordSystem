ScoobClient
===========

University Client
